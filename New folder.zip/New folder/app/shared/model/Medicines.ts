export class Medicines {
  productId!: number;
  name!: string;
  price!: number;
  sellerName!: string;
  description!: string;
  offer!: string;
  image!: string;
  active!: boolean;
}
